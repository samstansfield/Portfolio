"use strict"
var $ = function(id) { return document.getElementById(id);};

// The function for resetting the form.
var resetForm = function() {
	$("register").reset();
	$("fname").focus();
	var test = testForm();
};

/*  The following function will validate the form before it is submitted.  It returns a boolean value, true when 
complete and false when there are blank spaces.  It is also called from the onload function.  */
var testForm = function() {
	var flag=true;
	if($("fname").value == "") {
		$("fnameLabel").style.color = "red";
		flag=false;
	}  else {
		$("fnameLabel").style.color = "black";
	}
	
	if($("lname").value == "") {
		$("lnameLabel").style.color = "red";
		flag=false;
	}  else {
		$("lnameLabel").style.color = "black";
	}
	
	if($("address1").value == "") {
		$("address1Label").style.color = "red";
		flag=false;
	}  else {
		$("address1Label").style.color = "black";
	}
	
	if($("address2").value == "") {
		$("address2Label").style.color = "red";
		flag=false;
	}  else {
		$("address2Label").style.color = "black";
	}
	
	if($("city").value == "") {
		$("cityLabel").style.color = "red";
		flag=false;
	}  else {
		$("cityLabel").style.color = "black";
	}
	
	if($("state").value == "") {
		$("stateLabel").style.color = "red";
		flag=false;
	}  else {
		$("stateLabel").style.color = "black";
	}
	
	if($("zipcode").value == "") {
		$("zipcodeLabel").style.color = "red";
		flag=false;
	}  else {
		$("zipcodeLabel").style.color = "black";
	}
	
	if($("dob").value == "") {
		$("dobLabel").style.color = "red";
		flag=false;
	}  else {
		$("dobLabel").style.color = "black";
	}

	if($("mstatus").value == "") {
		$("mstatusLabel").style.color = "red";
		flag=false;
	}  else {
		$("mstatusLabel").style.color = "black";
	}
	
	if($("sname").value == "" && $("mstatus") == "married") {
		$("snameLabel").style.color = "red";
		flag=false;
	}  else {
		$("snameLabel").style.color = "black";
	}
	
	if($("email").value == "") {
		$("emailLabel").style.color = "red";
		flag=false;
	}  else {
		$("emailLabel").style.color = "black";
	}

	if($("phone").value == "") {
		$("phoneLabel").style.color = "red";
		flag=false;
	}  else {
		$("phoneLabel").style.color = "black";
	}
	
	if($("password").value == "" || $("password2").value == "" || $("password").value != $("password2").value) {
		flag=false;
		$("passwordLabel").style.color = "red";
		$("password2Label").style.color = "red";
		
	} else {
		$("passwordLabel").style.color = "black";
		$("password2Label").style.color = "black";
		
	}

	if(flag == true) {
		$("mySpan").setAttribute("hidden", true)
	}

	return flag;
};

//  The function for submitting the form.
var submitForm = function() {
	var result = testForm();
	if(result == true) {
	   $("register").submit();  
	}  
};


//  This function toggles the textbox for the spouse's name.  
document.onchange = function() { 
	if($("mstatus").value == "single"){$("sname").disabled=true};
	if($("mstatus").value == "married"){$("sname").disabled=false};
};	

//  This is the onload function.  The spouse's name starts out disabled since the default is single.
window.onload =function() {
	$("resetButton").onclick = resetForm;
	$("submitButton").onclick = submitForm;
	$("fname").focus();
	$("sname").disabled = true;
	var flag = testForm();
};

