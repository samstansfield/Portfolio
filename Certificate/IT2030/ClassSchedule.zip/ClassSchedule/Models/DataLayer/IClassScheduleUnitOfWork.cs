using Microsoft.EntityFrameworkCore;


namespace ClassSchedule.Models
{
    public interface IClassScheduleUnitOfWork
    {
        Repository<Teacher> Teachers {get;}
        Repository<Class> Classes {get;}
        Repository<Day> Days {get;}
        void Save();

    }
}